
from django.urls import path

urlpatterns = [
    # Tambahkan login, register, dashboard nanti
]
