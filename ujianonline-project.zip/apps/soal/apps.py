from django.apps import AppConfig

class SoalConfig(AppConfig):
    name = 'apps.soal'
