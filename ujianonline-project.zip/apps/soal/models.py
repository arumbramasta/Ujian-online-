
from django.db import models
from apps.mapel.models import Mapel
from apps.users.models import CustomUser

class Soal(models.Model):
    TIPE_CHOICES = (
        ('pg', 'Pilihan Ganda'),
        ('essay', 'Essay'),
    )
    mapel = models.ForeignKey(Mapel, on_delete=models.CASCADE)
    guru = models.ForeignKey(CustomUser, on_delete=models.CASCADE, limit_choices_to={'role': 'guru'})
    pertanyaan = models.TextField()
    tipe = models.CharField(max_length=10, choices=TIPE_CHOICES)

    # Untuk soal pilihan ganda
    opsi_a = models.CharField(max_length=255, blank=True, null=True)
    opsi_b = models.CharField(max_length=255, blank=True, null=True)
    opsi_c = models.CharField(max_length=255, blank=True, null=True)
    opsi_d = models.CharField(max_length=255, blank=True, null=True)
    jawaban_benar = models.CharField(max_length=1, blank=True, null=True)

    def __str__(self):
        return f"{self.pertanyaan[:50]}..."

class Ujian(models.Model):
    mapel = models.ForeignKey(Mapel, on_delete=models.CASCADE)
    guru = models.ForeignKey(CustomUser, on_delete=models.CASCADE, limit_choices_to={'role': 'guru'})
    nama = models.CharField(max_length=100)
    soal = models.ManyToManyField(Soal)
    durasi_menit = models.IntegerField()
    waktu_mulai = models.DateTimeField()

    def __str__(self):
        return self.nama

class Jawaban(models.Model):
    ujian = models.ForeignKey(Ujian, on_delete=models.CASCADE)
    siswa = models.ForeignKey(CustomUser, on_delete=models.CASCADE, limit_choices_to={'role': 'siswa'})
    soal = models.ForeignKey(Soal, on_delete=models.CASCADE)
    jawaban_teks = models.TextField(blank=True, null=True)
    jawaban_pg = models.CharField(max_length=1, blank=True, null=True)
    nilai = models.FloatField(blank=True, null=True)

    def __str__(self):
        return f"Jawaban {self.siswa.username} - {self.soal.id}"
