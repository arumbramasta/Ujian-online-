from django.apps import AppConfig

class MapelConfig(AppConfig):
    name = 'apps.mapel'
