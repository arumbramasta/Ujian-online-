
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('apps.users.urls')),
    path('mapel/', include('apps.mapel.urls')),
    path('soal/', include('apps.soal.urls')),
]
