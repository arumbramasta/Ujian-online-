from django.contrib import admin
from .models import Mapel
admin.site.register(Mapel)
