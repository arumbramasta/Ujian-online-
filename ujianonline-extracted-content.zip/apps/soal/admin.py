
from django.contrib import admin
from .models import Soal, Ujian, Jawaban

admin.site.register(Soal)
admin.site.register(Ujian)
admin.site.register(Jawaban)
